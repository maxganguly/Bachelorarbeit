package main.ast;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import main.generator.Generator;

public class ASTTestGenerator implements Generator{

	ASTTree code;
	
	public ASTTestGenerator(ASTTree code) {
		this.code = code;
	}
	
	@Override
	public List<ASTTestcase> generateTestcases() {
		var list = new LinkedList<ASTTestcase>();
		for(ASTTree method: code.getTreesWithTag("method")) {
			list.addAll(generateTestcases(method));
		}
		return list;
	}
	
	public List<ASTTestcase> generateTestcases(ASTTree method) {
		var list = new LinkedList<ASTTestcase>();
		list.add(new ASTTestcase(method.name+"Exact", method, 10));	
		ASTTree general = method.generalize();
		list.add(new ASTTestcase(method.name+"General", general, 5));
		ASTTree struct = general.keepOnlyStructure();
		list.add(new ASTTestcase(method.name+"Structure", struct, 1));
		ASTTree temp = getAllMethodCalls(general);
		if(temp != null)
		list.add(new ASTTestcase(method.name+"MethodCalls", temp , 1));
		temp = getHighestNestedLoop(general);
		if(temp != null)
			list.add(new ASTTestcase(method.name+"Loops", temp , 1));
		return list;
	}
	
	private ASTTree getAllMethodCalls(ASTTree tree) {
		var mc = tree.getTreesWithTag("mc").stream().map(t -> t.keepOnly("mc")).distinct().toList();
		ASTTree t = new ASTTree();
		t.children.addAll(mc);
		return t;
	}
	private ASTTree getHighestNestedLoop(ASTTree tree) {
		var loop = tree.keepOnly("loop");
		
		return null;
	}
	
	private ASTTree getRecursion(ASTTree tree) {
		return null;
	}
	
}
