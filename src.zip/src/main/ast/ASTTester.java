package main.ast;

import main.Pair;
import main.Tester;

public class ASTTester extends Tester<ASTTestcase> {

	ASTTree code;

	@Override
	public Pair<String, Integer> test(ASTTestcase testcase) {
		if(code.evaluate(testcase.tree)) {
			return new Pair<String, Integer>("Success: "+testcase.name, testcase.score);
		}
		return new Pair<String, Integer>("Failure: "+testcase.name, 0);
	}
	


}
